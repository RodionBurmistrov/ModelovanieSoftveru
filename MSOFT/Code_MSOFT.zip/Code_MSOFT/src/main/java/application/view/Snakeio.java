package application.view;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileInputStream;

import static application.view.WindowOne.controller;

/**
 * Definujem okno
 */
public class Snakeio extends Application  {

    public Button back = new Button("Back");
    public Pane pane = new Pane();
    public Scene scene = new Scene(pane, 800, 800);
    private Label LEurope = new Label("Snake.ios");
    public static Label LEUAuction = new Label(" ");
    public static Label informationEU = new Label("Information about game Snake.io:");

    public static Button EuropeRise = new Button("Vote");

    public static final Integer STARTTIMEEU = 15;//
    public static Timeline timelineEU;//
    public static Label timerLabelEU = new Label();//
    public static Integer timeSecondsEU = STARTTIMEEU;//

    /**
     * Aukcia, kde sa robia bid-y medzi pouzivatelmi za Europsku kontajner
     * @param stage scena
     */
    public void start(Stage stage)
    {
        try {

            Image EuropeContainer = new Image(new FileInputStream("Snake.jpg"));
            ImageView ViewEeuropeContainer = new ImageView();
            ViewEeuropeContainer.setImage(EuropeContainer);

            ViewEeuropeContainer.setX(200);
            ViewEeuropeContainer.setY(10);
            ViewEeuropeContainer.setFitHeight(400);
            ViewEeuropeContainer.setFitWidth(400);
            ViewEeuropeContainer.setPreserveRatio(true);
            pane.getChildren().add(ViewEeuropeContainer);

            back.setPrefHeight(30);
            back.setPrefWidth(100);
            back.setLayoutX(50);
            back.setLayoutY(250);
            pane.getChildren().add(back);

            LEurope.setPrefHeight(30);
            LEurope.setPrefWidth(150);
            LEurope.setLayoutX(50);
            LEurope.setLayoutY(100);
            pane.getChildren().add(LEurope);

            LEUAuction.setPrefHeight(300);
            LEUAuction.setPrefWidth(400);
            LEUAuction.setLayoutX(200);
            LEUAuction.setLayoutY(400);
            pane.getChildren().add(LEUAuction);

            informationEU.setPrefHeight(300);
            informationEU.setPrefWidth(300);
            informationEU.setLayoutX(100);
            informationEU.setLayoutY(600);
            pane.getChildren().add(informationEU);

            EuropeRise.setPrefHeight(30);
            EuropeRise.setPrefWidth(150);
            EuropeRise.setLayoutX(20);
            EuropeRise.setLayoutY(400);
            pane.getChildren().add(EuropeRise);

            timerLabelEU.setPrefHeight(30);
            timerLabelEU.setPrefWidth(150);
            timerLabelEU.setLayoutX(20);
            timerLabelEU.setLayoutY(600);
            timerLabelEU.setTextFill(Color.RED);
            timerLabelEU.setStyle("-fx-font-size: 4em;");
            pane.getChildren().add(timerLabelEU);


            EuropeRise.setOnAction( e -> controller.Bidding("europe"));

            stage.setScene(scene);
            SetAndInitialize();
            InitializeController();
            stage.show();


        } catch (Exception e) {
            e.printStackTrace();
        }

        back.setOnAction( e -> {stage.close();});

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        back.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        EuropeRise.setStyle("-fx-background-color: red; -fx-text-fill: white;");

    }


    /**
     * pripojenie kontrollera
     */
    public void InitializeController(){
    }
}
