package application.view;
import application.controller.Controller;
import application.utils.Styler;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Definujem prve okno a realizujem ho
 */
public class WindowOne extends Application  {

    public static Controller controller = null;

    public Button submit = new Button("Submit");
    public Button verification = new Button("Verification");
    public TextField t1nickname = new TextField();
    public TextField tpassword = new TextField();
    public TextField tspecial = new TextField();
    public Label lspecial = new Label("Special Number");
    public Label lname = new Label("Nickname");
    public Label lpassword = new Label("Password");
    public Label info = new Label("");
    public Pane pane = new Pane();
    public Scene scene = new Scene(pane, 400,400);

    /**
     * prve okno pre login, aby sa nalogovat, najprv treba sa zaregistrovat
     * @param stage - scena
     */
    @Override
    public void start(Stage stage) {
        try {
            stage.setScene(scene);
            SetAndInitialize();
            InitializeController();
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        verification.setOnAction( e -> controller.RegisterUser());
        submit.setOnAction( e -> {
            try {
                controller.SubmitUser(t1nickname.getText(), tpassword.getText(), tspecial.getText());
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        });

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize() {
        Styler.Set(this, lname, 60, 100, 100, 30, true);
        Styler.Set(this, t1nickname, 125, 100, 100, 30, true);
        Styler.Set(this, lpassword, 60, 150, 100, 30, true);
        Styler.Set(this, tpassword, 125, 150, 100, 30, true);
        Styler.Set(this, lspecial, 25, 200, 100, 30, true);
        Styler.Set(this, tspecial, 125, 200, 100, 30, true);
        Styler.Set(this, verification, 125, 250, 100, 30, true);
        Styler.Set(this, submit, 220, 250, 100, 30, true);
        Styler.Set(this, info, 150, 350, 100, 30, false);

        pane.setMinSize(400,200);
        pane.setPadding(new Insets(10, 10, 10, 10));

        submit.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        verification.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        t1nickname.setStyle("-fx-font: normal bold 20px 'serif'");
        tpassword.setStyle("-fx-font: normal bold 20px 'serif'");
    }

    /**
     * Pripojenie kontrollera
     */
    public void InitializeController() {
        controller = new Controller(this);
    }

    /**
     * Main
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }
}