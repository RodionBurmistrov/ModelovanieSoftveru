package application.view;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileInputStream;

import static application.view.WindowOne.controller;

/**
 * Definujem okno
 */
public class Amogusus extends Application  {


    public Button back = new Button("Back");
    public Pane pane = new Pane();
    public Scene scene = new Scene(pane, 800,800);
    private Label LAustralia = new Label("Amogusus");
    public static Label LAUAuction = new Label(" ");
    public static Label informationAU = new Label("Information about game Amogusus:");
    public static Button AustraliaRise = new Button("Vote");

    public static final Integer STARTTIMEAU = 15;
    public static Timeline timelineAU;
    public static Label timerLabelAU = new Label();
    public static Integer timeSecondsAU = STARTTIMEAU;


    public void start(Stage stage)
    {
        try {


            Image AustraliaContainer = new Image(new FileInputStream("Amogusus.jpg"));
            ImageView ViewAustraliaContainer = new ImageView();
            ViewAustraliaContainer.setImage(AustraliaContainer);

            ViewAustraliaContainer.setX(200);
            ViewAustraliaContainer.setY(10);
            ViewAustraliaContainer.setFitHeight(400);
            ViewAustraliaContainer.setFitWidth(400);
            ViewAustraliaContainer.setPreserveRatio(true);
            pane.getChildren().add(ViewAustraliaContainer);

            back.setPrefHeight(30);
            back.setPrefWidth(100);
            back.setLayoutX(50);
            back.setLayoutY(250);
            pane.getChildren().add(back);

            LAustralia.setPrefHeight(30);
            LAustralia.setPrefWidth(150);
            LAustralia.setLayoutX(50);
            LAustralia.setLayoutY(100);
            pane.getChildren().add(LAustralia);

            LAUAuction.setPrefHeight(300);
            LAUAuction.setPrefWidth(400);
            LAUAuction.setLayoutX(200);
            LAUAuction.setLayoutY(400);
            pane.getChildren().add(LAUAuction);

            informationAU.setPrefHeight(300);
            informationAU.setPrefWidth(300);
            informationAU.setLayoutX(100);
            informationAU.setLayoutY(600);
            pane.getChildren().add(informationAU);

            AustraliaRise.setPrefHeight(30);
            AustraliaRise.setPrefWidth(150);
            AustraliaRise.setLayoutX(20);
            AustraliaRise.setLayoutY(400);
            pane.getChildren().add(AustraliaRise);

            timerLabelAU.setPrefHeight(30);
            timerLabelAU.setPrefWidth(150);
            timerLabelAU.setLayoutX(20);
            timerLabelAU.setLayoutY(600);
            timerLabelAU.setTextFill(Color.BLACK);
            timerLabelAU.setStyle("-fx-font-size: 4em;");
            pane.getChildren().add(timerLabelAU);


            AustraliaRise.setOnAction(e -> controller.Bidding("australia"));


            stage.setScene(scene);
            SetAndInitialize();
            InitializeController();
            stage.show();


        } catch (Exception e) {
            e.printStackTrace();
        }

        back.setOnAction( e -> {stage.close();});

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        back.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        AustraliaRise.setStyle("-fx-background-color: green; -fx-text-fill: white;");

    }

    /**
     * pripojenie kontrollera
     */
    public void InitializeController(){
    }
}




