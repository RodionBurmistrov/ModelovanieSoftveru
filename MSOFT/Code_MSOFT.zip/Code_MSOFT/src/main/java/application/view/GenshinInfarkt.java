package application.view;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileInputStream;

import static application.view.WindowOne.controller;

/**
 * Definujem okno
 */
public class GenshinInfarkt extends Application  {

    public static Button back = new Button("Back");
    public Pane pane = new Pane();
    public Scene scene = new Scene(pane, 800,800);
    private Label LDubai = new Label("Genshin Infarkt");
    public static Label LDUAuction = new Label(" ");
    public static Label informationDU = new Label("Information about game Genshing Infarkt:");
    public static Button DubaiRise = new Button("Vote");

    public static final Integer STARTTIMEDU = 15;//
    public static Timeline timelineDU;//
    public static Label timerLabelDU = new Label();//
    public static Integer timeSecondsDU = STARTTIMEDU;//



    public void start(Stage stage)
    {
        try {

            Image DubaiContainer = new Image(new FileInputStream("Genshin_infarkt.jpg"));
            ImageView ViewDubaiContainer = new ImageView();
            ViewDubaiContainer.setImage(DubaiContainer);

            ViewDubaiContainer.setX(200);
            ViewDubaiContainer.setY(10);
            ViewDubaiContainer.setFitHeight(400);
            ViewDubaiContainer.setFitWidth(400);
            ViewDubaiContainer.setPreserveRatio(true);
            pane.getChildren().add(ViewDubaiContainer);

            back.setPrefHeight(30);
            back.setPrefWidth(100);
            back.setLayoutX(50);
            back.setLayoutY(250);
            pane.getChildren().add(back);

            LDubai.setPrefHeight(30);
            LDubai.setPrefWidth(150);
            LDubai.setLayoutX(50);
            LDubai.setLayoutY(100);
            pane.getChildren().add(LDubai);

            LDUAuction.setPrefHeight(300);
            LDUAuction.setPrefWidth(400);
            LDUAuction.setLayoutX(200);
            LDUAuction.setLayoutY(400);
            pane.getChildren().add(LDUAuction);

            informationDU.setPrefHeight(300);
            informationDU.setPrefWidth(300);
            informationDU.setLayoutX(100);
            informationDU.setLayoutY(600);
            pane.getChildren().add(informationDU);

            DubaiRise.setPrefHeight(30);
            DubaiRise.setPrefWidth(150);
            DubaiRise.setLayoutX(20);
            DubaiRise.setLayoutY(400);
            pane.getChildren().add(DubaiRise);

            timerLabelDU.setPrefHeight(30);
            timerLabelDU.setPrefWidth(150);
            timerLabelDU.setLayoutX(20);
            timerLabelDU.setLayoutY(600);
            timerLabelDU.setTextFill(Color.GREEN);
            timerLabelDU.setStyle("-fx-font-size: 4em;");
            pane.getChildren().add(timerLabelDU);


            DubaiRise.setOnAction( e -> controller.Bidding("dubai"));


            stage.setScene(scene);
            SetAndInitialize();
            InitializeController();
            stage.show();



        } catch (Exception e) {
            e.printStackTrace();
        }

        back.setOnAction( e -> {stage.close();});

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        back.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        DubaiRise.setStyle("-fx-background-color: yellow; -fx-text-fill: black;");

    }

    /**
     * pripojenie kontrollera
     */
    public void InitializeController(){

    }
}
