package application.view;

import application.controller.GlobalNickname;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

import static application.view.WindowOne.controller;

/**
 * Definujem okno - menu
 */
public class WindowMenu extends Application {

    private Label l2nickname = new Label(" ");
    public static Label SoldItems = new Label(" ");
    public Button exit = new Button("Exit");

    /**
     * okno - menu pouzivatela, kam sa dostava do itemov, sleduje ake veci boli kupene,
     * a dostava sa na aukcie
     * @param stage scena
     */
    public void start(Stage stage) {
        try {

            SetAndInitialize();
            InitializeController();
            User();


            Menu Auctions = new Menu("Games");

            MenuItem dubai = new MenuItem("Genshin Infarkt");
            MenuItem america = new MenuItem("Clash of clash");
            MenuItem europe = new MenuItem("Snake.ios");
            MenuItem australia = new MenuItem("Amogusus");

            Auctions.getItems().addAll(dubai, america, europe, australia);

            MenuBar menuBar = new MenuBar();
            menuBar.setTranslateX(50);
            menuBar.setTranslateY(20);
            menuBar.getMenus().addAll(Auctions);

            Group pane = new Group(menuBar);
            Scene scene = new Scene(pane, 800, 800);
            stage.setScene(scene);
            stage.show();

            l2nickname.setText("Hello, "+GlobalNickname.nickname);

            l2nickname.setPrefHeight(30);
            l2nickname.setPrefWidth(150);
            l2nickname.setLayoutX(50);
            l2nickname.setLayoutY(100);
            pane.getChildren().add(l2nickname);

            SoldItems.setPrefHeight(500);
            SoldItems.setPrefWidth(200);
            SoldItems.setLayoutX(400);
            SoldItems.setLayoutY(100);
            pane.getChildren().add(SoldItems);


            exit.setPrefHeight(30);
            exit.setPrefWidth(100);
            exit.setLayoutX(50);
            exit.setLayoutY(250);
            pane.getChildren().add(exit);


            SetAndInitialize();
            InitializeController();
            stage.show();
            dubai.setOnAction( e -> controller.GoToDubai());
            america.setOnAction( e -> controller.GoToAmerica());
            europe.setOnAction( e -> controller.GoToEurope());
            australia.setOnAction( e -> controller.GoToAustralia());



        } catch (Exception e) {
            e.printStackTrace();
        }

        exit.setOnAction( e -> {
            try {
                controller.UkladanieUdajov();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            stage.close();});

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        exit.setStyle("-fx-background-color: black; -fx-text-fill: white;");
    }

    /**
     * Pripojenie kontrollera
     */
    public void InitializeController(){
    }

    /**
     * pripojenie Usera, s jeho vlastymi udajmi
     */
    public void User(){
    }
}
