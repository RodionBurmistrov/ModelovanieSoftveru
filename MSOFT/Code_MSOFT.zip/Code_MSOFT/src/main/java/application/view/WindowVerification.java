package application.view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.io.*;

import static application.view.WindowOne.controller;

/**
 * okno registracii pouzivatela
 */
public class WindowVerification extends Application  {

    private TextField tRnickname = new TextField();
    private TextField tRpassword = new TextField();

    private Label lRnickname = new Label("Nickname");
    private Label lRpassword = new Label("Password");

    private Label tRtext = new Label(" ");
    private static int cislo = 0;
    public Button register = new Button("Verificate");

    /**
     * druhe okno pre registraciu, tu treba zadat nickname a heslo,
     * potom sa ti prideli specialne cislo, ktore si musis zapamatat
     * @param stage scena
     */
    @Override
    public void start(Stage stage) {
        try {
            Pane pane = new Pane();
            Scene scene = new Scene(pane, 400,400);
            stage.setScene(scene);

            lRnickname.setPrefHeight(30);
            lRnickname.setPrefWidth(150);
            lRnickname.setLayoutX(50);
            lRnickname.setLayoutY(100);
            pane.getChildren().add(lRnickname);

            tRnickname.setPrefHeight(30);
            tRnickname.setPrefWidth(150);
            tRnickname.setLayoutX(150);
            tRnickname.setLayoutY(100);
            pane.getChildren().add(tRnickname);

            lRpassword.setPrefHeight(30);
            lRpassword.setPrefWidth(150);
            lRpassword.setLayoutX(50);
            lRpassword.setLayoutY(200);
            pane.getChildren().add(lRpassword);

            tRpassword.setPrefHeight(30);
            tRpassword.setPrefWidth(150);
            tRpassword.setLayoutX(150);
            tRpassword.setLayoutY(200);
            pane.getChildren().add(tRpassword);

            register.setPrefHeight(30);
            register.setPrefWidth(100);
            register.setLayoutX(50);
            register.setLayoutY(250);
            pane.getChildren().add(register);

            tRtext.setPrefHeight(60);
            tRtext.setPrefWidth(600);
            tRtext.setLayoutX(50);
            tRtext.setLayoutY(300);
            pane.getChildren().add(tRtext);

            SetAndInitialize();
            InitializeController();
            stage.show();


            register.setOnAction(e -> {

            String name = tRnickname.getText();
            String password = tRpassword.getText();

                tRtext.setText("Hello "+name+" you were successfuly verificated.");
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Your special key number is "+cislo+" please remember it");
                alert.showAndWait();
                writeNewUser(name, password, cislo);

                try {
                    controller.Databasing(name, password);
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                }

                cislo = cislo + 1;
                stage.close();
         });



        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        register.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        tRnickname.setStyle("-fx-font: normal bold 10px 'serif'");
        tRpassword.setStyle("-fx-font: normal bold 10px 'serif'");
    }

    /**
     * Pripojenie kontrollera
     */
    public void InitializeController(){
    }

    /**
     * priebeha zapis udajov pouzivatela do textoveho suboru
     * @param text      - prijima nickname, ktory uzer zadal
     * @param password  - prijima heslo, ktore user zadal
     * @param cislo     - specialne cislo, ktore dostane pouzivatel
     */
    public void writeNewUser(String text, String password, int cislo) {

        File fw = new File("text.txt");

        try {
            if (!fw.exists()){
                System.out.println("we had to create a new file");
                fw.createNewFile();
            }
            FileWriter filewriter = new FileWriter(fw, true);
            BufferedWriter bw = new BufferedWriter(filewriter);
            bw.write(text+" ");
            bw.write(password+" ");
            bw.write(cislo+" ");

            bw.newLine();

            bw.close();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
