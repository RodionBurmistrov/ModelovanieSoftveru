package application.view;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileInputStream;

import static application.view.WindowOne.controller;

/**
 * Definujem okno
 */
public class ClashOfClashes extends Application  {

    //Vonkajsok

    public Button back = new Button("Back");
    public Pane pane = new Pane();
    public Scene scene = new Scene(pane, 800,800);
    private Label LAmerica = new Label("Clash of Clashes");
    public static Label LAMAuction = new Label(" ");
    public static Label informationAM = new Label("Information about game Clash of Clashes:");
    public static Button AmericaRise = new Button("Vote");

    public static final Integer STARTTIMEAM = 5;//
    public static Timeline timelineAM;//
    public static Label timerLabelAM = new Label();//
    public static Integer timeSecondsAM = STARTTIMEAM;//



    public void start(Stage stage)
    {
        try {

            Image AmericaContainer = new Image(new FileInputStream("Clash_of_clashes.jpg"));
            ImageView ViewAmericaContainer = new ImageView();
            ViewAmericaContainer.setImage(AmericaContainer);

            ViewAmericaContainer.setX(200);
            ViewAmericaContainer.setY(10);
            ViewAmericaContainer.setFitHeight(400);
            ViewAmericaContainer.setFitWidth(400);
            ViewAmericaContainer.setPreserveRatio(true);
            pane.getChildren().add(ViewAmericaContainer);

            back.setPrefHeight(30);
            back.setPrefWidth(100);
            back.setLayoutX(50);
            back.setLayoutY(250);
            pane.getChildren().add(back);

            LAmerica.setPrefHeight(30);
            LAmerica.setPrefWidth(150);
            LAmerica.setLayoutX(50);
            LAmerica.setLayoutY(100);
            pane.getChildren().add(LAmerica);

            LAMAuction.setPrefHeight(300);
            LAMAuction.setPrefWidth(400);
            LAMAuction.setLayoutX(200);
            LAMAuction.setLayoutY(400);
            pane.getChildren().add(LAMAuction);

            informationAM.setPrefHeight(300);
            informationAM.setPrefWidth(300);
            informationAM.setLayoutX(100);
            informationAM.setLayoutY(600);
            pane.getChildren().add(informationAM);

            AmericaRise.setPrefHeight(30);
            AmericaRise.setPrefWidth(150);
            AmericaRise.setLayoutX(20);
            AmericaRise.setLayoutY(400);
            pane.getChildren().add(AmericaRise);

            timerLabelAM.setPrefHeight(30);
            timerLabelAM.setPrefWidth(150);
            timerLabelAM.setLayoutX(20);
            timerLabelAM.setLayoutY(600);
            timerLabelAM.setTextFill(Color.BLUE);
            timerLabelAM.setStyle("-fx-font-size: 4em;");
            pane.getChildren().add(timerLabelAM);


            AmericaRise.setOnAction( e -> controller.Bidding("america")); //, nickname

            stage.setScene(scene);
            SetAndInitialize();
            InitializeController();
            stage.show();


        } catch (Exception e) {
            e.printStackTrace();
        }

        back.setOnAction( e -> {stage.close();});

    }

    /**
     * Pouziva sa Styler, urceny v utils/Styler
     */
    public void SetAndInitialize(){
        back.setStyle("-fx-background-color: black; -fx-text-fill: white;");
        AmericaRise.setStyle("-fx-background-color: blue; -fx-text-fill: white;");

    }

    /**
     * pripojenie kontrollera
     */
    public void InitializeController(){
    }


/*
    @Override               //неправильно, этого старта быть не должно
    public void start(Stage stage) throws Exception {
    }

 */
}
