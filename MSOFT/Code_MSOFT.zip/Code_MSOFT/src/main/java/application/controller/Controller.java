package application.controller;

import application.model.User;
import application.utils.Database;
import application.view.*;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.*;

/**
 * Controller, ktore ma niekolko uloh. Vytvora okna, sprostredkova prechod na dalsie okna, alebo Controllery (Bids)
 * Uklada udaje pouzivatelov pri registracii, loguje ich na zaklade rovnakosti udajov pri registracii, zapisuje do "Databasy"
 * Uklada udaje z "Databazy" pri odstupe pouzivatelov.
 */
public class Controller {
    private WindowOne _window;


    /**
     * Zakladne prve okno
     * @param window
     */
    public Controller(WindowOne window) {
        this._window = window;
    }

    /**
     * Posiela na okno Registracii
      */
    public void RegisterUser()
    {
        try {
            new WindowVerification().start(new Stage());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static int cislocloveka = 0;

    /**
     * Priebeha porovnanie udajov pri logovani s udajmi, ktore boli zapisane v textovy dokument pri registracii
      * @param nickname - nickname pouzivatela zadany pri logovani
     * @param password - heslo pouzivatela zadany pri logovani
     * @param cislo - identifikacne cislo pouzivatela zadane pri logovani
     * @throws IOException
     */
    public void SubmitUser(String nickname, String password, String cislo) throws IOException {

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("text.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("chyba textak XD");
            e.printStackTrace();
        }
        if (br != null) {
            String st;
            while ((st = br.readLine()) != null) {
                String[] splitted = st.split(" ");
                if (nickname.equals(splitted[0]) && password.equals(splitted[1]) && cislo.equals(splitted[2])) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("You were logged in "+nickname);
                    alert.showAndWait();

                    cislocloveka = Integer.parseInt(cislo);

                    GlobalNickname.nickname = nickname;
                    if(SaveDownCast())
                    {
                        ((WindowOne)_window).info.setText("User were logged "+nickname);
                        ((WindowOne)_window).info.setVisible(true);
                    }
                    try {
                        new WindowMenu().start(new Stage());

                    } catch (Exception e){
                        e.printStackTrace();
                    }
                    br.close();
                    break;
                }
            }
        }

    }

    /**
     * Posiela na okno Dubai
     */
    public void GoToDubai()
    {
        try {
            new GenshinInfarkt().start(new Stage());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Posiela na okno Amerika
     */
    public void GoToAmerica()
    {
        try {
            new ClashOfClashes().start(new Stage());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Posiela na okno Europe
     */
    public void GoToEurope()
    {
        try {
            new Snakeio().start(new Stage());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Posiela na okno Australia
     */
    public void GoToAustralia()
    {
        try {
            new Amogusus().start(new Stage());
        } catch (Exception e){
            e.printStackTrace();
        }
    }

//    /**
//     * Posiela na okno Itemy
//     */
//    public void GoToItems()
//    {
//        try {
//            new Windowitems().start(new Stage());
//        } catch (Exception e){
//            e.printStackTrace();
//        }
//    }

    /**
     * Posiela zmeny v stavkach z Aukcij do controlleru Bids
     */
    public void Bidding(String country)
    {
        switch(country) {
            case "dubai":
                Bids.setBid(Bids.getBid("dubai") + 1000,"dubai");
                break;
            case "america":
                Bids.setBid(Bids.getBid("america") + 1000,"america");
                break;
            case "australia":
                Bids.setBid(Bids.getBid("australia") + 1000,"australia");
                break;
            case "europe":
                Bids.setBid(Bids.getBid("europe") + 1000,"europe");
                break;
            default:
                System.out.println("Cringe bidding XD");
        }

    }

    /**
     * Pri Registracii pouzivatela ulozi jeho aktualne udaje do "Databazy"
     */
    public void Databasing(String name, String password) throws IOException {

        User newRegistredUser = new User(name, password, 0);
        Database.getInstance().getUsers().add(newRegistredUser);
        Database.getInstance().getCurrentUsers().add(newRegistredUser);
        Database.getInstance().getMoney().add(newRegistredUser);
    }

    /**
     * Pri Odhlaseni pouzivatela ulozi jeho aktualne udaje z "Databazy"
     */
    public void UkladanieUdajov() throws IOException {

        File td = new File("Databasa.txt");

        try {
            if (!td.exists()){
                System.out.println("we had to create a new file");
                td.createNewFile();
            }
            FileWriter filewriter = new FileWriter(td, true);
            BufferedWriter bw = new BufferedWriter(filewriter);
            bw.write(Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()+" ");
            bw.write(Database.getInstance().getCurrentUsers().get(cislocloveka).getPassword()+" ");
            bw.write(Database.getInstance().getCurrentUsers().get(cislocloveka).getMoney()+" ");
            bw.write(Database.getInstance().getCurrentUsers().get(cislocloveka).getContaineritems()+" ");

            bw.newLine();

            bw.close();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    private boolean SaveDownCast() {
        return this._window instanceof WindowOne;
    }
}
