package application.controller;

import application.utils.Database;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.util.Duration;

import static application.controller.Controller.cislocloveka;
import static application.view.ClashOfClashes.*;
import static application.view.Amogusus.*;
import static application.view.GenshinInfarkt.*;
import static application.view.Snakeio.*;

/**
 * klassa, ktora kontroluje vsetko co sa deje v Aukciach
 * Dostava aktualny bid, meni ho, ak niekto chce zvysit.
 * Obsahuje v sebe aj timer, po ukoncenf ktoreho ukaze aka vec bola v contajnere
 * a prideli ju tomu, kto spravil najvissi bid.
 * Tak isto zmeni udaj pouzivatela o tom, kolko minul penaz na aukciach
 */
public class Bids {
        private static int newMoney = 0;
        private static double bidDubai = 0, bidAmerica = 0, bidAustralia = 0, bidEurope = 0;

        public static void setBid(double bidNew, String country){  //String nickname
            switch(country) {
                case "dubai":
                    bidDubai = bidNew;
                    LDUAuction.setText("*Adverticement Alert!*: Please try New Game - It calls BravlBabs!");

                    if (timelineDU != null) {
                        timelineDU.stop();
                    }
                    timeSecondsDU = STARTTIMEDU;
                    // obnoveny timerLabel
                    timerLabelDU.setText(timeSecondsDU.toString());
                    timelineDU = new Timeline();
                    timelineDU.setCycleCount(Timeline.INDEFINITE);
                    // KeyFrame event
                    timelineDU.getKeyFrames().add(
                            new KeyFrame(Duration.seconds(1),
                                    (EventHandler<javafx.event.ActionEvent>) event -> {
                                        timeSecondsDU--;
                                        // obnoveny timerLabel
                                        timerLabelDU.setText(
                                                timeSecondsDU.toString());
                                        if (timeSecondsDU <= 0) {
                                            informationDU.setText(Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()+" you voted for Genshin Infarkt");

                                            newMoney = (int) (Integer.parseInt(Database.getInstance().getCurrentUsers().get(cislocloveka).getMoney()) + bidDubai);
                                            Database.getInstance().getCurrentUsers().get(cislocloveka).setMoney(String.valueOf(newMoney));
                                            newMoney = 0;

                                            timelineDU.stop();
                                            bidDubai = 0;
                                        }
                                    }));
                    timelineDU.playFromStart();

                    break;

                case "america":
                    bidAmerica = bidNew;
                    LAMAuction.setText("*Adverticement Alert!*: Please try New Game - It calls Snake.io!");

                    if (timelineAM != null) {
                        timelineAM.stop();
                    }
                    timeSecondsAM = STARTTIMEAM;
                    // obnoveny timerLabel
                    timerLabelAM.setText(timeSecondsAM.toString());
                    timelineAM = new Timeline();
                    timelineAM.setCycleCount(Timeline.INDEFINITE);
                    // KeyFrame event
                    timelineAM.getKeyFrames().add(
                            new KeyFrame(Duration.seconds(1),
                                    (EventHandler<javafx.event.ActionEvent>) event -> {
                                        timeSecondsAM--;
                                        // obnoveny timerLabel
                                        timerLabelAM.setText(
                                                timeSecondsAM.toString());
                                        if (timeSecondsAM <= 0) {
                                            informationAM.setText(Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()+" you voted for Clash of clash");

                                            newMoney = (int) (Integer.parseInt(Database.getInstance().getCurrentUsers().get(cislocloveka).getMoney()) + bidAmerica);
                                            Database.getInstance().getCurrentUsers().get(cislocloveka).setMoney(String.valueOf(newMoney));
                                            newMoney = 0;

                                            timelineAM.stop();
                                            bidAmerica = 0;
                                        }
                                    }));
                    timelineAM.playFromStart();

                    break;

                case "australia":

                    bidAustralia = bidNew;
                    LAUAuction.setText("*Adverticement Alert!*: Please try New Game - It calls Genshin Infarkt!");

                    if (timelineAU != null) {
                        timelineAU.stop();
                    }
                    timeSecondsAU = STARTTIMEAU;
                    // obnoveny timerLabel
                    timerLabelAU.setText(timeSecondsAU.toString());
                    timelineAU = new Timeline();
                    timelineAU.setCycleCount(Timeline.INDEFINITE);
                    // KeyFrame event
                    timelineAU.getKeyFrames().add(
                            new KeyFrame(Duration.seconds(1),
                                    (EventHandler<javafx.event.ActionEvent>) event -> {
                                        timeSecondsAU--;
                                        // obnoveny timerLabel
                                        timerLabelAU.setText(
                                                timeSecondsAU.toString());
                                        if (timeSecondsAU <= 0) {
                                            informationAU.setText(Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()+" you voted for Amogusus");

                                            newMoney = (int) (Integer.parseInt(Database.getInstance().getCurrentUsers().get(cislocloveka).getMoney()) + bidAustralia);
                                            Database.getInstance().getCurrentUsers().get(cislocloveka).setMoney(String.valueOf(newMoney));
                                            newMoney = 0;

                                            timelineAU.stop();
                                            bidAustralia = 0;
                                        }
                                    }));
                    timelineAU.playFromStart();

                    break;

                case "europe":
                    bidEurope = bidNew;
                    LEUAuction.setText("*Adverticement Alert!*: Please try New Game - It calls Amogusus!");

                    if (timelineEU != null) {
                        timelineEU.stop();
                    }
                    timeSecondsEU = STARTTIMEEU;
                    // obnoveny timerLabel
                    timerLabelEU.setText(timeSecondsEU.toString());
                    timelineEU = new Timeline();
                    timelineEU.setCycleCount(Timeline.INDEFINITE);
                    // KeyFrame event
                    timelineEU.getKeyFrames().add(
                            new KeyFrame(Duration.seconds(1),
                                    (EventHandler<javafx.event.ActionEvent>) event -> {
                                        timeSecondsEU--;
                                        // obnoveny timerLabel
                                        timerLabelEU.setText(
                                                timeSecondsEU.toString());
                                        if (timeSecondsEU <= 0) {
                                            informationEU.setText(Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()+" you voted for Snake.ios");

                                            newMoney = (int) (Integer.parseInt(Database.getInstance().getCurrentUsers().get(cislocloveka).getMoney()) + bidEurope);
                                            Database.getInstance().getCurrentUsers().get(cislocloveka).setMoney(String.valueOf(newMoney));
                                            newMoney = 0;

                                            timelineEU.stop();
                                            bidEurope = 0;
                                        }
                                    }));
                    timelineEU.playFromStart();

                    break;

                default:
                    System.out.println("Cringe setbid XD");
            }

        }

        public static int getBid(String country) {
            switch (country) {
                case "dubai":
                    return (int) bidDubai;
                case "america":
                    return (int) bidAmerica;
                case "australia":
                    return (int) bidAustralia;
                case "europe":
                    return (int) bidEurope;
                default:
                    System.out.println("Cringe getbid XD");
            }
           return 0;
        }

}