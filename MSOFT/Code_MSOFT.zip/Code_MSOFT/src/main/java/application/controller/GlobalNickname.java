package application.controller;

/**
 * Globalna premenna, ktora oznacuje aktualneho nalogovaneho uzera.
 * Da sa zmenit jednoducho na Database.getInstance().getCurrentUsers().get(cislocloveka).getNickname()
 * ale som sa rozhodol to nechat, z dovodu vacsiej prehliadnosti (podla mojho nazoru) niektorych casti kodu
 */
public class GlobalNickname {
    public static String nickname;
}
