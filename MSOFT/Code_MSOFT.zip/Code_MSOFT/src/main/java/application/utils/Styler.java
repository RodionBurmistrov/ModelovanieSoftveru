package application.utils;

import application.view.WindowOne;
import javafx.scene.Node;

/**
 * Styler, krory sa pouziva pri View
 */
public class Styler {

    public static void Set(WindowOne application, Node node, int pozx, int pozy, int width, int height, boolean visiable)
    {
        node.minWidth(width);
        node.minHeight(height);
        node.setLayoutX(pozx);
        node.setLayoutY(pozy);
        node.setVisible(visiable);
        application.pane.getChildren().add(node);

    }
}
