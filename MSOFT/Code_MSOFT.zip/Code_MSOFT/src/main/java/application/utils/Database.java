package application.utils;

import application.model.User;

import java.util.ArrayList;

/**
 * "Databaza" ktory je skutocny Arraylist,
 * sem sa zapisuju Nickname usera, jeho heslo, Veci, ktore boli kupene userom na aukcii
 * a pocet paniaz, ktore pouzivatel minul na Aukciach celkovo
 */
public class Database {

    private static final ArrayList<User> databaseOfUsers = new ArrayList<User>();
    private static final ArrayList<User> currentlyLoggedInUsers = new ArrayList<User>();
    private static final ArrayList<User> databaseOfItemsofUsers = new ArrayList<User>();
    private static final ArrayList<User> databaseOfMoney = new ArrayList<User>();

    private static Database dat;

    private Database(){
    }

    public static Database getInstance(){
        if(dat == null) dat = new Database();
        return dat;
    }

    public ArrayList<User> getMoney() {
        return databaseOfMoney;
    }


    public ArrayList<User> getUsers() {
return databaseOfUsers;
    }

    public ArrayList<User> getCurrentUsers() {
        return currentlyLoggedInUsers;
    }

    public ArrayList<User> getUserContaineritems() {
        return databaseOfItemsofUsers;
    }

}

