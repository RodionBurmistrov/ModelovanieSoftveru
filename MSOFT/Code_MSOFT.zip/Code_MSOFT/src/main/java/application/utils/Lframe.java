package application.utils;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * interface, ktory sa nikde nepouziva
 */
public interface Lframe {
    void SetAndInitialize(Stage stage);
    void InitializeController();

}
