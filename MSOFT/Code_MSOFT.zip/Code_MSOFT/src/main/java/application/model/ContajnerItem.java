package application.model;

/**
 * Abstractna classa ContajnerItem, ktorej patria veci, ktore sa mozu nachadzat v kontajneri
 */
public abstract class ContajnerItem {
  public abstract double getPrice();
}
