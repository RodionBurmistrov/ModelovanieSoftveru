package application.model;

import java.util.ArrayList;

/**
 * Pouzivatel, a vsetko co k nemu patri: meno, heslo, veci z aukcij, pocet minutych peniaz.
 * priklad pouzitia set-erov a get-erov
 */
public class User {

    public String getNickname() {
        return nickname;
    }

    public String getPassword() {
        return password;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }




    public ArrayList<ContajnerItem> getContaineritems() {
        return containeritems;
    }

    private String nickname;
    private String money;
    private String password;
    private ArrayList<ContajnerItem> containeritems;


    /**
     * sa prideluju udaje pouzivatelovi
     * @param nickname  - nickname
     * @param password  - heslo
     * @param money     - pocet minutych peniaz
     */
    public User(String nickname, String password, int money){
        containeritems = new ArrayList<>();
        this.nickname = nickname;
        this.password = password;
        this.money = String.valueOf(money);

    }
}
