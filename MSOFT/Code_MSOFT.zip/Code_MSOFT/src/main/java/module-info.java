module com.example.projectoop {
    requires javafx.controls;
    requires javafx.fxml;


    opens application.view to javafx.fxml;
    exports application.view;
}